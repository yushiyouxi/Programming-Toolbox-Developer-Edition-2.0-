#!/bin/bash
# 编程工具箱启动脚本（macOS / Linux）
cd "$(dirname "$0")"
(python3 server.py || python server.py)
