@echo off
chcp 65001 >nul
title 编程工具箱
python server.py 2>nul || python3 server.py 2>nul || py server.py
if errorlevel 1 (
  echo.
  echo 未检测到 Python，请先安装 Python 并勾选 "Add python.exe to PATH"
  echo 下载地址: https://www.python.org/downloads/
  pause
)
