# -*- coding: utf-8 -*-
"""
编程工具箱 - 后端服务（仅用 Python 标准库，无需安装任何依赖）
启动: python server.py  然后浏览器打开 http://127.0.0.1:8686
"""
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = os.path.dirname(os.path.abspath(__file__))
WEB_DIR = os.path.join(ROOT, "web")
CODES_DIR = os.path.join(ROOT, "codes")
TSINGHUA = "https://pypi.tuna.tsinghua.edu.cn/simple"
PORT = 8687
# 版本标记：False = 标准版（不含开发者版内容）；True = 开发者版（独立发行）
DEV_EDITION = True

os.makedirs(CODES_DIR, exist_ok=True)

PY_CMD = shutil.which("python3") or shutil.which("python") or sys.executable
GXX_CMD = shutil.which("g++")
PIP_OK = True
try:
    subprocess.run([PY_CMD, "-m", "pip", "--version"], capture_output=True, timeout=15)
except Exception:
    PIP_OK = False


def detect_env():
    py_ver = ""
    if PY_CMD:
        try:
            r = subprocess.run([PY_CMD, "--version"], capture_output=True, text=True, timeout=10)
            py_ver = (r.stdout or r.stderr).strip()
        except Exception:
            py_ver = ""
    gxx_ver = ""
    if GXX_CMD:
        try:
            r = subprocess.run([GXX_CMD, "--version"], capture_output=True, text=True, timeout=10)
            gxx_ver = r.stdout.splitlines()[0].strip() if r.stdout else ""
        except Exception:
            gxx_ver = ""
    return {
        "python": {"ok": bool(py_ver), "version": py_ver, "path": PY_CMD or ""},
        "cpp": {"ok": bool(gxx_ver), "version": gxx_ver, "path": GXX_CMD or ""},
        "pip": {"ok": PIP_OK},
    }


DEFAULT_CODE = {
    "python": "# 欢迎使用编程工具箱！\nprint(\"Hello, 编程工具箱!\")\n",
    "cpp": "#include <iostream>\nusing namespace std;\n\nint main() {\n    cout << \"Hello, 编程工具箱!\" << endl;\n    return 0;\n}\n",
}
EXT = {"python": ".py", "cpp": ".cpp"}


def list_codes(lang=None):
    out = []
    for f in sorted(os.listdir(CODES_DIR)):
        for l, e in EXT.items():
            if f.endswith(e) and (lang is None or lang == l):
                p = os.path.join(CODES_DIR, f)
                out.append({"name": f, "lang": l,
                            "mtime": int(os.path.getmtime(p)),
                            "size": os.path.getsize(p)})
    out.sort(key=lambda x: -x["mtime"])
    return out


def safe_name(name):
    name = os.path.basename(name)
    return re.sub(r"[^\w\-.]", "_", name)


def run_python(code):
    with tempfile.NamedTemporaryFile("w", suffix=".py", delete=False, encoding="utf-8") as f:
        f.write(code)
        path = f.name
    try:
        r = subprocess.run([PY_CMD, path], capture_output=True, text=True,
                           timeout=15, encoding="utf-8", errors="replace")
        return {"ok": r.returncode == 0, "returncode": r.returncode,
                "stdout": r.stdout[-20000:], "stderr": r.stderr[-20000:]}
    except subprocess.TimeoutExpired:
        return {"ok": False, "returncode": -1, "stdout": "", "stderr": "运行超时（超过 15 秒），已强制终止。"}
    finally:
        os.unlink(path)


def run_cpp(code):
    tmpdir = tempfile.mkdtemp()
    src = os.path.join(tmpdir, "main.cpp")
    exe = os.path.join(tmpdir, "main.exe" if os.name == "nt" else "main")
    try:
        with open(src, "w", encoding="utf-8") as f:
            f.write(code)
        c = subprocess.run([GXX_CMD, src, "-o", exe, "-std=c++17"],
                           capture_output=True, text=True, timeout=60,
                           encoding="utf-8", errors="replace")
        if c.returncode != 0:
            return {"ok": False, "stage": "编译失败", "returncode": c.returncode,
                    "stdout": "", "stderr": c.stderr[-20000:]}
        r = subprocess.run([exe], capture_output=True, text=True, timeout=15,
                           encoding="utf-8", errors="replace", input="")
        return {"ok": r.returncode == 0, "stage": "运行", "returncode": r.returncode,
                "stdout": r.stdout[-20000:], "stderr": r.stderr[-20000:]}
    except subprocess.TimeoutExpired:
        return {"ok": False, "stage": "运行超时", "returncode": -1, "stdout": "",
                "stderr": "运行超时（超过 15 秒），已强制终止。"}
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


def pypi_search(q):
    """先按包名精确查 PyPI JSON API；查不到则给出提示，可用 pip 命令安装。"""
    q = q.strip()
    if not q:
        return {"found": False, "results": []}
    url = f"https://pypi.org/pypi/{urllib.parse.quote(q)}/json"
    try:
        with urllib.request.urlopen(url, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        info = data["info"]
        return {"found": True, "results": [{
            "name": info["name"], "version": info["version"],
            "summary": (info.get("summary") or "")[:200],
            "home": info.get("project_url") or (info.get("urls") and "") or "",
        }]}
    except Exception:
        return {"found": False, "results": [],
                "tip": f"PyPI 上没有找到名为 “{q}” 的包。可以确认拼写，或直接在下方输入完整 pip 命令安装。"}


import urllib.parse  # noqa: E402  (放在函数使用后亦可，Python 允许模块级导入)


def pip_install(pkg, raw_cmd=""):
    if raw_cmd:
        m = re.search(r"pip3?\s+install\s+(.+)", raw_cmd.strip())
        if not m:
            return {"ok": False, "output": "无法识别的 pip 命令，格式应为: pip install 包名"}
        args = m.group(1).split()
    else:
        args = [pkg]
    args = [a for a in args if a]
    cmd = [PY_CMD, "-m", "pip", "install"] + args + ["-i", TSINGHUA]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=300,
                           encoding="utf-8", errors="replace")
        out = (r.stdout or "") + (r.stderr or "")
        # PEP 668 受管环境（部分新版 Linux）：自动追加 --break-system-packages 重试一次
        if r.returncode != 0 and "externally-managed-environment" in out:
            cmd += ["--break-system-packages"]
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=300,
                               encoding="utf-8", errors="replace")
            out = (r.stdout or "") + (r.stderr or "")
        return {"ok": r.returncode == 0, "output": out[-20000:],
                "cmd": " ".join(cmd)}
    except subprocess.TimeoutExpired:
        return {"ok": False, "output": "安装超时（超过 5 分钟）。"}
    except Exception as e:
        return {"ok": False, "output": f"安装失败: {e}"}


def pip_list():
    try:
        r = subprocess.run([PY_CMD, "-m", "pip", "list", "--format=json"],
                           capture_output=True, text=True, timeout=30)
        return json.loads(r.stdout) if r.returncode == 0 else []
    except Exception:
        return []


DOWNLOADS = {
    "interpreters": [
        {"name": "Python 官方安装包", "desc": "Windows / macOS 官方安装程序，安装时记得勾选 “Add python.exe to PATH”。",
         "url": "https://www.python.org/downloads/", "tag": "解释器", "icon": "🐍"},
        {"name": "MinGW-w64 (g++ 编译器)", "desc": "Windows 下最常用的 C++ 编译器（winlibs 构建版），解压后把 bin 目录加入 PATH。",
         "url": "https://winlibs.com/", "tag": "编译器", "icon": "⚙️"},
        {"name": "MSYS2", "desc": "Windows 上的完整开发环境，可一键安装 gcc/g++：pacman -S mingw-w64-x86_64-gcc。",
         "url": "https://www.msys2.org/", "tag": "编译器", "icon": "🧰"},
        {"name": "Python 清华镜像", "desc": "国内下载 Python 相关资源更快（pip 源已默认使用清华镜像）。",
         "url": "https://mirrors.tuna.tsinghua.edu.cn/", "tag": "镜像", "icon": "🪞"},
    ],
    "ai": [
        {"name": "Ollama", "desc": "一键在本地运行开源大模型（Llama 3、Qwen、DeepSeek 等），命令行即可对话。",
         "url": "https://ollama.com/download", "tag": "本地大模型", "icon": "🦙"},
        {"name": "LM Studio", "desc": "带图形界面的本地大模型运行器，可从 Hugging Face 直接下载 GGUF 模型。",
         "url": "https://lmstudio.ai/", "tag": "本地大模型", "icon": "🖥️"},
        {"name": "Hugging Face", "desc": "全球最大的开源 AI 模型社区，海量模型与数据集免费下载。",
         "url": "https://huggingface.co/models", "tag": "模型库", "icon": "🤗"},
        {"name": "ModelScope 魔搭", "desc": "阿里开源模型社区，国内下载速度快，Qwen 全系列模型可下载。",
         "url": "https://modelscope.cn/models", "tag": "模型库", "icon": "🚀"},
        {"name": "Open WebUI", "desc": "开源的本地 AI 聊天界面，配合 Ollama 使用体验极佳。",
         "url": "https://github.com/open-webui/open-webui", "tag": "AI 界面", "icon": "💬"},
        {"name": "Chatbox", "desc": "开源跨平台 AI 客户端，支持接入本地或在线模型。",
         "url": "https://chatboxai.app/", "tag": "AI 客户端", "icon": "📦"},
    ],
}

# ---------------- 报错排查规则（源自 debug-pro 7 步排查协议） ----------------
DEBUG_RULES = [
    (r"ModuleNotFoundError: No module named '([\w\.]+)'",
     "缺少 Python 第三方模块",
     "程序 import 的模块没有安装（或不在当前解释器环境中）。",
     "到「扩展」模块搜索并安装该包，或在终端执行: pip install {0} -i {1}"),
    (r"ImportError",
     "导入错误",
     "模块存在但导入失败，常见于循环导入、模块名与自己的文件名冲突。",
     "检查是否有文件与库同名（如 random.py）；检查循环导入。"),
    (r"IndentationError|TabError",
     "缩进错误",
     "Python 靠缩进划分代码块，混用 Tab 和空格或缩进层级不对都会报错。",
     "统一使用 4 个空格缩进；对齐 if/for/def 下面的代码块。"),
    (r"SyntaxError",
     "语法错误",
     "代码不符合语言语法：常见为漏写冒号、括号不配对、中文引号/标点。",
     "看报错指向的行和 ^ 位置；把中文标点（“ ” ， ：）改成英文标点。"),
    (r"NameError: name '(\w+)'",
     "变量未定义",
     "使用了不存在的变量名 “{0}”：拼写错误、忘记赋值、或作用域不对。",
     "检查变量拼写与大小写；确认在使用前已赋值。"),
    (r"TypeError: (.+)",
     "类型错误",
     "对不匹配的类型做了运算，例如字符串和数字相加、把函数当变量调用。",
     "用 type() 或 print() 确认变量类型后再运算；必要时做类型转换。"),
    (r"ZeroDivisionError",
     "除以零错误",
     "除数为 0，数学上未定义。",
     "在做除法前判断除数是否为 0。"),
    (r"FileNotFoundError.*(No such file|找不到文件)?",
     "文件不存在",
     "open() 的文件路径不对，或文件不在当前工作目录。",
     "用绝对路径，或先 os.path.exists() 检查；注意 Windows 路径要用 r'...' 原始字符串。"),
    (r"PermissionError",
     "权限不足",
     "没有读写该文件/目录的权限，或文件正被其他程序占用。",
     "关闭占用该文件的程序；Windows 下可尝试以管理员身份运行。"),
    (r"RecursionError",
     "递归过深",
     "递归没有正确的终止条件，或递归层数超过默认上限(1000)。",
     "检查递归函数的 base case；确有必要时用 sys.setrecursionlimit() 调大或改写成循环。"),
    (r"KeyError: (.+)",
     "字典键不存在",
     "访问了字典中没有的键 {0}。",
     "用 dict.get(key, 默认值) 代替 dict[key]，或先判断 key in dict。"),
    (r"IndexError",
     "列表下标越界",
     "访问了列表/元组中不存在的位置（下标超出长度-1，或用了负数越界）。",
     "先用 len() 检查长度；注意下标从 0 开始。"),
    (r"AttributeError: '(\w+)' object has no attribute '(\w+)'",
     "对象没有该属性",
     "在 {0} 类型对象上访问了不存在的属性/方法 “{1}”，常见于拼写错误或类型搞混。",
     "用 dir(obj) 查看可用属性；确认变量真的是你以为的类型。"),
    (r"ValueError",
     "值错误",
     "类型对但值不合法，例如 int('abc')。",
     "转换前先校验输入；用 try/except ValueError 兜底。"),
    (r"UnicodeDecodeError|UnicodeEncodeError",
     "编码错误",
     "文件编码与读取编码不一致（常见 GBK 与 UTF-8 混用）。",
     "open() 时显式指定 encoding='utf-8'。"),
    (r"undefined reference to `?([\w:]+)'?",
     "C++ 链接错误：未定义引用",
     "函数/变量声明了但没有实现，或忘了把对应的 .cpp 一起编译、忘了链接库。",
     "检查函数是否实现；多文件要一起编译；用到数学库时加 -lm 等链接参数。"),
    (r"expected `;'",
     "C++ 语法错误：缺少分号",
     "某条语句末尾漏写了分号（报错行号常常指向下一行）。",
     "检查报错行的上一行末尾是否缺 ;。"),
    (r"‘([\w]+)’ was not declared in this scope|'([\w]+)' was not declared in this scope",
     "C++ 标识符未声明",
     "使用了未声明/未包含头文件的标识符。",
     "补上对应的 #include，或检查拼写与命名空间（如 std::）。"),
    (r"Segmentation fault|段错误|SIGSEGV",
     "段错误（内存访问违规）",
     "访问了非法内存：空指针、数组越界、野指针、无限递归耗尽栈。",
     "检查指针是否初始化；检查数组下标范围；用 g++ -g 编译后配合 gdb 定位。"),
    (r"collect2: error|ld returned",
     "C++ 链接失败",
     "链接器无法生成可执行文件，通常伴随 undefined reference。",
     "查看上方第一条真正的错误信息，按链接错误处理。"),
    (r"str object cannot be interpreted as an integer|can only concatenate str",
     "字符串与数字混用",
     "Python 中字符串不能直接和数字相加或做下标运算。",
     "用 str() 或 int() 显式转换类型。"),
]

SEVEN_STEPS = [
    ("1. 复现", "稳定地重现错误，记下确切的输入、操作步骤和完整报错信息。"),
    ("2. 隔离", "缩小范围：注释掉一半代码做二分定位，找出真正出错的最小片段。"),
    ("3. 假设", "针对根因提出一个具体、可验证的猜测（而不是乱改）。"),
    ("4. 插桩", "加 print/日志、断点或断言，观察关键变量的实际值。"),
    ("5. 验证", "确认根因；如果假设错了，回到第 3 步重新假设。"),
    ("6. 修复", "做最小、正确的修改——调试期间忍住不要顺手重构。"),
    ("7. 回归", "写一个能捕获该 bug 的测试，确认修复后测试通过。"),
]


def analyze_error(text):
    text = (text or "").strip()
    if not text:
        return {"hits": [], "steps": SEVEN_STEPS, "empty": True}
    hits = []
    for pat, title, cause, fix in DEBUG_RULES:
        m = re.search(pat, text)
        if m:
            groups = [g for g in m.groups() if g]
            try:
                cause_f = cause.format(*groups) if groups else cause
            except Exception:
                cause_f = cause
            try:
                fix_f = fix.format(*(groups + [TSINGHUA])) if "{" in fix else fix
            except Exception:
                fix_f = fix
            hits.append({"title": title, "cause": cause_f, "fix": fix_f,
                         "matched": m.group(0)[:120]})
            if len(hits) >= 4:
                break
    # 提取 Traceback 中的文件与行号
    locs = re.findall(r'File "([^"]+)", line (\d+)', text)
    return {"hits": hits, "steps": SEVEN_STEPS,
            "locations": [{"file": f, "line": int(l)} for f, l in locs[-3:]]}


# ---------------- 编程教学（源自 code-mentor 教学模式） ----------------
LESSONS = [
    {"id": "py-basics", "lang": "Python", "level": "入门", "icon": "🐍",
     "title": "Python 基础：变量、类型与运算",
     "summary": "从零认识变量、数字/字符串/布尔类型、f-string 与基本运算。",
     "content": [
        {"h": "变量与类型", "p": "Python 不需要声明类型，赋值即创建。用 type() 可以查看类型。",
         "code": "name = \"小明\"      # str 字符串\nage = 18            # int 整数\nheight = 1.72       # float 浮点数\nis_student = True   # bool 布尔\nprint(type(name), type(age))"},
        {"h": "f-string 格式化", "p": "在字符串前加 f，用 {} 嵌入变量，是最推荐的拼接方式。",
         "code": "name, age = \"小明\", 18\nprint(f\"我叫{name}，今年{age}岁，明年{age + 1}岁\")"},
        {"h": "输入与转换", "p": "input() 拿到的永远是字符串，参与数学运算前要用 int()/float() 转换。",
         "code": "s = input(\"请输入一个整数: \")\nn = int(s)\nprint(\"它的平方是\", n * n)"},
        {"h": "练一练", "p": "写一个程序：输入圆的半径，输出周长和面积（π 取 3.14159）。可到「编程」模块新建 Python 代码练习。", "code": ""}]},
    {"id": "py-flow", "lang": "Python", "level": "入门", "icon": "🔀",
     "title": "Python 流程控制：if / for / while",
     "summary": "条件判断、循环、break/continue，以及 range 的三种用法。",
     "content": [
        {"h": "条件判断", "p": "注意 Python 用缩进（4 个空格）表示代码块，条件行末尾必须有冒号。",
         "code": "score = 85\nif score >= 90:\n    print(\"优秀\")\nelif score >= 60:\n    print(\"及格\")\nelse:\n    print(\"不及格\")"},
        {"h": "for 与 range", "p": "range(a, b, step) 生成 [a, b) 的整数序列，常配合 for 使用。",
         "code": "for i in range(1, 10, 2):   # 1 3 5 7 9\n    print(i, end=\" \")\nprint()\nfor ch in \"Python\":          # 遍历字符串\n    print(ch)"},
        {"h": "while 与 break", "p": "while 适合“不知道循环几次”的场景，务必保证循环能结束。",
         "code": "n = 0\nwhile True:\n    n += 1\n    if n * n > 100:\n        break\nprint(f\"第一个平方超过100的数是 {n}\")"},
        {"h": "练一练", "p": "打印九九乘法表（提示：两层 for 循环 + f-string 对齐）。", "code": ""}]},
    {"id": "py-func", "lang": "Python", "level": "进阶", "icon": "🧩",
     "title": "Python 函数与模块",
     "summary": "def 定义函数、参数默认值、返回值、作用域，以及 import 模块。",
     "content": [
        {"h": "定义与调用", "p": "函数把一段逻辑打包复用。没有 return 的函数返回 None——这是新手常见 bug。",
         "code": "def add(a, b):\n    return a + b\n\nprint(add(3, 5))\n\ndef greet(name=\"世界\"):   # 默认参数\n    return f\"你好, {name}!\"\n\nprint(greet(), greet(\"千问\"))"},
        {"h": "多返回值与作用域", "p": "Python 可以一次返回多个值（其实是元组）。函数内赋值默认不影响外部变量。",
         "code": "def min_max(nums):\n    return min(nums), max(nums)\n\nlo, hi = min_max([3, 1, 4, 1, 5])\nprint(lo, hi)"},
        {"h": "使用模块", "p": "标准库随 Python 自带；第三方库需先 pip install（可用「扩展」模块安装，默认清华源）。",
         "code": "import random, math\nprint(random.randint(1, 6))      # 掷骰子\nprint(math.sqrt(2))              # 根号2\nfrom datetime import datetime\nprint(datetime.now())"},
        {"h": "练一练", "p": "写函数 is_prime(n) 判断质数，再用它找出 100 以内所有质数。", "code": ""}]},
    {"id": "py-ds", "lang": "Python", "level": "进阶", "icon": "📚",
     "title": "Python 数据结构：列表 / 字典 / 集合",
     "summary": "四大容器的增删改查、切片、推导式与常见 KeyError/IndexError 陷阱。",
     "content": [
        {"h": "列表与切片", "p": "列表有序可变。切片 [start:end:step] 是最常用的操作之一。",
         "code": "a = [10, 20, 30, 40, 50]\nprint(a[1:4])     # [20, 30, 40]\nprint(a[::-1])    # 反转\na.append(60)\na[0] = 99\nprint(a)"},
        {"h": "字典", "p": "键值对容器，查找是 O(1)。用 get() 避免 KeyError。",
         "code": "scores = {\"语文\": 90, \"数学\": 95}\nscores[\"英语\"] = 88          # 新增\nprint(scores.get(\"物理\", 0))  # 不存在给默认值\nfor k, v in scores.items():\n    print(k, v)"},
        {"h": "推导式", "p": "一行生成列表/字典/集合，简洁且快。",
         "code": "squares = [x * x for x in range(10) if x % 2 == 0]\nprint(squares)   # [0, 4, 16, 36, 64]"},
        {"h": "练一练", "p": "统计一段英文文本中每个单词出现的次数（提示：字典 + get）。", "code": ""}]},
    {"id": "cpp-basics", "lang": "C++", "level": "入门", "icon": "🅲",
     "title": "C++ 基础：从 Hello World 到变量输入",
     "summary": "编译型语言的程序结构、iostream 输入输出、变量类型与编译流程。",
     "content": [
        {"h": "程序结构", "p": "C++ 需要先 #include 头文件，main 是程序入口。写完要用 g++ 编译成可执行文件再运行（工具箱会自动完成）。",
         "code": "#include <iostream>\nusing namespace std;\n\nint main() {\n    cout << \"Hello, C++!\" << endl;\n    return 0;\n}"},
        {"h": "变量与类型", "p": "C++ 是静态类型语言：声明时必须写类型。常用 int / double / char / string / bool。",
         "code": "#include <iostream>\n#include <string>\nusing namespace std;\n\nint main() {\n    int age = 18;\n    double height = 1.72;\n    string name = \"小明\";\n    cout << name << \" \" << age << \" \" << height << endl;\n    return 0;\n}"},
        {"h": "输入与运算", "p": "cin >> 读入变量；注意 C++ 中 int / int 结果仍是 int（整数除法会截断）。",
         "code": "#include <iostream>\nusing namespace std;\n\nint main() {\n    int a, b;\n    cout << \"输入两个整数: \";\n    cin >> a >> b;\n    cout << \"和=\" << a + b\n         << \" 商(int)=\" << a / b\n         << \" 商(double)=\" << (double)a / b << endl;\n    return 0;\n}"},
        {"h": "练一练", "p": "输入摄氏温度，输出华氏温度（F = C × 9 / 5 + 32）。", "code": ""}]},
    {"id": "cpp-flow", "lang": "C++", "level": "入门", "icon": "🔁",
     "title": "C++ 流程控制与函数",
     "summary": "if/for/while、函数定义与声明、引用传参、常见编译错误对照。",
     "content": [
        {"h": "条件与循环", "p": "和 Python 不同，C++ 用 {} 划分代码块，条件要加圆括号。",
         "code": "#include <iostream>\nusing namespace std;\n\nint main() {\n    for (int i = 1; i <= 9; i++) {\n        for (int j = 1; j <= i; j++)\n            cout << j << \"*\" << i << \"=\" << i * j << \"\\t\";\n        cout << endl;\n    }\n    return 0;\n}"},
        {"h": "函数与传参", "p": "& 表示引用传参，函数内修改会影响外部变量；不加 & 则是拷贝。",
         "code": "#include <iostream>\nusing namespace std;\n\nvoid swap2(int &a, int &b) {\n    int t = a; a = b; b = t;\n}\n\nint main() {\n    int x = 1, y = 2;\n    swap2(x, y);\n    cout << x << \" \" << y << endl;   // 2 1\n    return 0;\n}"},
        {"h": "常见编译错误", "p": "遇到报错别慌，拿到「报错排查」模块粘贴即可分析。最常见的三种：expected ';'（漏分号）、was not declared（没包含头文件或拼错）、undefined reference（函数没实现）。",
         "code": ""},
        {"h": "练一练", "p": "写函数 int fact(int n) 计算阶乘，输出 1!~10!。", "code": ""}]},
    {"id": "algo", "lang": "通用", "level": "进阶", "icon": "🧠",
     "title": "算法入门：复杂度与三个经典问题",
     "summary": "O 记号、双指针、哈希表思想；两数之和 / 反转 / 二分的经典解法。",
     "content": [
        {"h": "时间复杂度", "p": "O(n) 表示耗时随数据量线性增长，O(n²) 是平方增长——n=10000 时前者 1 万次操作、后者 1 亿次。写完代码先问自己：这是多少复杂度？",
         "code": ""},
        {"h": "经典：两数之和（哈希表 O(n)）", "p": "暴力双重循环是 O(n²)；用字典“边扫边记”可降到 O(n)。",
         "code": "def two_sum(nums, target):\n    seen = {}                     # 值 -> 下标\n    for i, v in enumerate(nums):\n        if target - v in seen:\n            return [seen[target - v], i]\n        seen[v] = i\n    return []\n\nprint(two_sum([2, 7, 11, 15], 9))  # [0, 1]"},
        {"h": "经典：二分查找（O(log n)）", "p": "有序数组中每次排除一半，100 万个数最多查 20 次。",
         "code": "def bsearch(a, x):\n    lo, hi = 0, len(a) - 1\n    while lo <= hi:\n        mid = (lo + hi) // 2\n        if a[mid] == x:\n            return mid\n        if a[mid] < x:\n            lo = mid + 1\n        else:\n            hi = mid - 1\n    return -1\n\nprint(bsearch([1, 3, 5, 7, 9], 7))  # 3"},
        {"h": "练一练", "p": "给一个字符串，判断它是否为回文（正读反读一样）。再想想 O(n) 的双指针解法。", "code": ""}]},
    {"id": "debug-method", "lang": "通用", "level": "进阶", "icon": "🕵️",
     "title": "调试方法论：七步排查协议",
     "summary": "复现→隔离→假设→插桩→验证→修复→回归，像侦探一样定位 bug。",
     "content": [
        {"h": "为什么要方法论", "p": "新手改 bug 靠“瞎试”，老手靠流程。七步协议的核心是：每次只验证一个假设，用证据说话。",
         "code": ""},
        {"h": "隔离：二分定位法", "p": "不确定哪段代码有问题时，注释掉一半。如果错误消失，问题就在这一半；否则在另一半。反复二分，几次就能锁定。",
         "code": "# 怀疑这一段有问题？先注释掉验证\n# result = complex_transform(data)\nresult = data   # 临时直通，看错误是否消失"},
        {"h": "插桩：让变量开口说话", "p": "print 是最朴素也最有效的调试工具。打印“你以为的值”和“实际的值”，差异处就是 bug。",
         "code": "def calc(items):\n    total = 0\n    for it in items:\n        print(f\"DEBUG: it={it!r} type={type(it).__name__} total={total}\")\n        total += it\n    return total"},
        {"h": "Python 官方调试器 pdb", "p": "在代码中插入 breakpoint()，运行到此会暂停，可逐行执行、查看变量。",
         "code": "def f(n):\n    breakpoint()      # 运行到这里暂停 (Python 3.7+)\n    return n * 2\n\nf(21)\n# 暂停后常用命令: n 下一行 / p 变量名 打印 / c 继续 / q 退出"},
        {"h": "回归测试", "p": "修好 bug 后写一个小测试防止它复活——这一步 90% 的人会跳过，但它是工程质量的分水岭。",
         "code": "def add(a, b):\n    return a + b\n\ndef test_add():\n    assert add(1, 2) == 3\n    assert add(-1, 1) == 0\n    print(\"all tests passed\")\n\ntest_add()"}]},
    {"id": "oop", "lang": "Python", "level": "高级", "icon": "🏛️",
     "title": "面向对象与常用设计模式",
     "summary": "类与对象、继承、封装；单例/工厂/策略三个最常用设计模式。",
     "content": [
        {"h": "类与继承", "p": "类是模板，对象是实例。__init__ 是构造方法，self 指代当前对象。",
         "code": "class Animal:\n    def __init__(self, name):\n        self.name = name\n    def speak(self):\n        return \"...\"\n\nclass Dog(Animal):\n    def speak(self):          # 重写父类方法\n        return f\"{self.name}: 汪汪!\"\n\nfor a in [Animal(\"某动物\"), Dog(\"旺财\")]:\n    print(a.speak())"},
        {"h": "工厂模式", "p": "把“创建哪个对象”的决定集中到一处，调用方不关心具体类——新增类型时不用改调用代码。",
         "code": "class Cat(Animal):\n    def speak(self): return f\"{self.name}: 喵~\"\n\ndef animal_factory(kind, name):\n    return {\"dog\": Dog, \"cat\": Cat}.get(kind, Animal)(name)\n\nprint(animal_factory(\"cat\", \"咪咪\").speak())"},
        {"h": "策略模式", "p": "把可互换的算法做成函数/对象传入，避免大串 if-else。Python 里函数就是对象，天然适合。",
         "code": "def sort_by_price(items):\n    return sorted(items, key=lambda x: x[\"price\"])\n\ndef sort_by_name(items):\n    return sorted(items, key=lambda x: x[\"name\"])\n\ndef report(items, strategy=sort_by_price):\n    return [i[\"name\"] for i in strategy(items)]\n\ndata = [{\"name\": \"b\", \"price\": 2}, {\"name\": \"a\", \"price\": 9}]\nprint(report(data), report(data, sort_by_name))"},
        {"h": "单一职责原则", "p": "一个类只负责一件事。如果你发现类名里有“Manager/Handler”且方法五花八门，多半该拆分了。",
         "code": ""}]},
    # ---------------- 开发者版专属课程 ----------------
    {"id": "dev-flask", "lang": "Python", "level": "开发者版", "icon": "🌐", "dev": True,
     "title": "Web 开发入门：用 Flask 写你的第一个网站",
     "summary": "路由、请求参数、返回 JSON；十几行代码跑起一个 Web 服务。",
     "content": [
        {"h": "安装与最小应用", "p": "先到「扩展」模块安装 flask（默认清华源）。下面几行代码就是一个能访问的网站。",
         "code": "from flask import Flask\napp = Flask(__name__)\n\n@app.route(\"/\")\ndef home():\n    return \"<h1>你好，我的第一个网站!</h1>\"\n\napp.run(port=5000)"},
        {"h": "路由与参数", "p": "路径里可以带变量；/api 风格接口一般返回 JSON。",
         "code": "from flask import Flask, jsonify, request\napp = Flask(__name__)\n\n@app.route(\"/user/<name>\")\ndef user(name):\n    age = request.args.get(\"age\", \"未知\")\n    return jsonify({\"name\": name, \"age\": age})\n\napp.run(port=5000)\n# 浏览器访问: http://127.0.0.1:5000/user/小明?age=18"},
        {"h": "练一练", "p": "写一个 /add?a=1&b=2 接口，返回两数之和的 JSON。", "code": ""}]},
    {"id": "dev-git", "lang": "通用", "level": "开发者版", "icon": "🌿", "dev": True,
     "title": "Git 版本控制：从第一次提交到分支协作",
     "summary": "init/add/commit、分支、合并、回退，开发者每天都在用的命令。",
     "content": [
        {"h": "第一次提交", "p": "Git 把项目变成一本可以随意翻页、随时回退的“历史记录本”。",
         "code": "git init                      # 初始化仓库\ngit add .                     # 把改动放入暂存区\ngit commit -m \"第一个版本\"     # 存档\ngit log --oneline             # 查看历史"},
        {"h": "分支：平行宇宙", "p": "在分支上做实验，不影响主线；成功后再合并回来。",
         "code": "git branch feature-login      # 建分支\ngit checkout feature-login    # 切过去开发\n# ...写完代码, add + commit...\ngit checkout main\ngit merge feature-login       # 合并回主线"},
        {"h": "后悔药", "p": "改坏了别慌，三条命令覆盖 90% 的救场需求。",
         "code": "git checkout -- 文件名   # 丢弃某文件的未提交修改\ngit reset HEAD~1         # 撤销上一次提交(保留改动)\ngit revert <commit-id>   # 用一次新提交抵消旧提交(安全)"},
        {"h": "练一练", "p": "把工具箱的 codes/ 目录 git init，每写一个练习就 commit 一次，再用 git log 回顾。", "code": ""}]},
    {"id": "dev-test", "lang": "Python", "level": "开发者版", "icon": "🧪", "dev": True,
     "title": "单元测试：用 pytest 给代码上保险",
     "summary": "断言、测试组织、边界用例；修 bug 前先写一个能复现它的测试。",
     "content": [
        {"h": "为什么写测试", "p": "没有测试的代码，每次修改都是拆盲盒。测试是“回归”的底气——改完一跑，全绿才敢交。",
         "code": "# calc.py\ndef add(a, b):\n    return a + b\n\n# test_calc.py\ndef test_add():\n    assert add(1, 2) == 3\n    assert add(-1, -1) == -2\n    assert add(0, 0) == 0\n# 先在扩展模块安装 pytest, 终端运行: pytest -v"},
        {"h": "边界用例", "p": "bug 最爱藏在边界：空列表、0、负数、超长输入、None。写测试时先想“什么输入会让它炸”。",
         "code": "def avg(nums):\n    if not nums:\n        raise ValueError(\"空列表\")\n    return sum(nums) / len(nums)\n\ndef test_avg_edge():\n    import pytest\n    assert avg([2, 4]) == 3\n    with pytest.raises(ValueError):\n        avg([])"},
        {"h": "与调试联动", "p": "发现 bug 的标准流程：先写一个失败的测试复现它 → 修代码 → 测试变绿。这就是七步协议的最后一步“回归”。",
         "code": ""},
        {"h": "练一练", "p": "给「函数与模块」课程里的 is_prime(n) 写 5 个测试用例（含 0、1、负数、大质数）。", "code": ""}]},
    {"id": "dev-package", "lang": "Python", "level": "开发者版", "icon": "📮", "dev": True,
     "title": "项目工程化：目录结构与打包发布",
     "summary": "像专业项目一样组织代码：模块划分、requirements、打包成 wheel 发布。",
     "content": [
        {"h": "标准目录结构", "p": "小脚本可以单文件，正式项目建议这样组织：",
         "code": "myproject/\n├── myproject/          # 源码包\n│   ├── __init__.py\n│   └── core.py\n├── tests/              # 测试\n│   └── test_core.py\n├── requirements.txt    # 依赖清单\n└── pyproject.toml      # 打包配置"},
        {"h": "依赖管理", "p": "requirements.txt 让别人（和未来的你）一键还原环境。",
         "code": "# 导出当前环境依赖\npip freeze > requirements.txt\n# 在新机器上一键安装(配合清华源)\npip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple"},
        {"h": "打包发布", "p": "用官方 build 工具打包，产物在 dist/ 目录，可上传 PyPI 让全世界 pip install 你的库。",
         "code": "pip install build twine\npython -m build          # 生成 dist/*.whl 和 *.tar.gz\ntwine upload dist/*      # 发布到 PyPI(需注册账号)"},
        {"h": "练一练", "p": "把你写过的 is_prime 打包成 mytools 库，本机安装 dist 里的 whl 后用 import mytools 验证。", "code": ""}]},
]


# ---------------- AI 大模型（本地 Ollama） ----------------
OLLAMA = "http://127.0.0.1:11434"


def ai_status():
    """探测本地 Ollama 是否可用及已安装的模型列表。"""
    try:
        with urllib.request.urlopen(OLLAMA + "/api/tags", timeout=3) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        models = [m["name"] for m in data.get("models", [])]
        return {"ok": True, "engine": "ollama", "models": models}
    except Exception:
        return {"ok": False, "engine": "ollama", "models": []}


def ai_generate(prompt, lang="python", model=""):
    st = ai_status()
    if not st["ok"]:
        return {"ok": False, "need_ai": True,
                "error": "未检测到本地 AI 大模型服务（Ollama）。请到「下载」模块安装 Ollama，然后执行 ollama pull qwen2.5-coder 下载一个代码模型。"}
    if not st["models"]:
        return {"ok": False, "need_ai": True,
                "error": "Ollama 已运行但还没有任何模型。请在终端执行: ollama pull qwen2.5-coder（或你喜欢的其他模型）。"}
    model = model or st["models"][0]
    sys_prompt = ("你是一个代码生成器。根据用户需求只输出一段完整的、可直接运行的"
                  + ("Python" if lang == "python" else "C++")
                  + "代码，代码放在一个 ``` 代码块中，附少量中文注释，不要输出其他多余解释。")
    payload = json.dumps({"model": model, "prompt": prompt, "system": sys_prompt,
                          "stream": False}).encode("utf-8")
    try:
        req = urllib.request.Request(OLLAMA + "/api/generate", payload,
                                     {"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=180) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        text = data.get("response", "")
    except Exception as e:
        return {"ok": False, "error": f"调用 AI 模型失败: {e}"}
    m = re.search(r"```[\w+\-]*\n(.*?)```", text, re.S)
    code = m.group(1).strip() if m else text.strip()
    if not code:
        return {"ok": False, "error": "AI 返回内容为空，请换个描述再试一次。"}
    ext = EXT.get(lang, ".py")
    name = f"AI_生成{len([f for f in os.listdir(CODES_DIR) if f.startswith('AI_生成')]) + 1}{ext}"
    with open(os.path.join(CODES_DIR, name), "w", encoding="utf-8") as f:
        f.write(code + "\n")
    return {"ok": True, "name": name, "lang": lang, "content": code + "\n",
            "model": model}


class Handler(BaseHTTPRequestHandler):
    server_version = "CodeToolbox/1.0"

    def log_message(self, fmt, *args):
        pass  # 静默日志

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        data = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _json_body(self):
        n = int(self.headers.get("Content-Length") or 0)
        try:
            return json.loads(self.rfile.read(n).decode("utf-8")) if n else {}
        except Exception:
            return {}

    def do_GET(self):
        path = urllib.parse.urlparse(self.path).path
        qs = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        if path == "/" or path == "/index.html":
            return self._file(os.path.join(WEB_DIR, "index.html"), "text/html; charset=utf-8")
        if path.startswith("/api/"):
            return self.api_get(path, qs)
        return self._send(404, {"error": "not found"})

    def _file(self, p, ctype):
        try:
            with open(p, "rb") as f:
                self._send(200, f.read(), ctype)
        except FileNotFoundError:
            self._send(404, {"error": "file not found"})

    def api_get(self, path, qs):
        if path == "/api/env":
            return self._send(200, detect_env())
        if path == "/api/code/list":
            lang = (qs.get("lang") or [None])[0]
            return self._send(200, {"files": list_codes(lang)})
        if path == "/api/ext/installed":
            return self._send(200, {"packages": pip_list()})
        if path == "/api/ext/search":
            q = (qs.get("q") or [""])[0]
            return self._send(200, pypi_search(q))
        if path == "/api/ai/status":
            return self._send(200, ai_status())
        if path == "/api/downloads":
            return self._send(200, DOWNLOADS)
        if path == "/api/lessons":
            ls = [l for l in LESSONS if DEV_EDITION or not l.get("dev")]
            return self._send(200, {"lessons": [
                {**{k: l[k] for k in ("id", "lang", "level", "icon", "title", "summary")},
                 "dev": l.get("dev", False)}
                for l in ls]})
        if path.startswith("/api/lesson/"):
            lid = path.rsplit("/", 1)[-1]
            for l in LESSONS:
                if l["id"] == lid:
                    if l.get("dev") and not DEV_EDITION:
                        return self._send(404, {"error": "该课程仅开发者版可用"})
                    return self._send(200, l)
            return self._send(404, {"error": "lesson not found"})
        return self._send(404, {"error": "not found"})

    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        body = self._json_body()
        if path == "/api/code/new":
            lang = body.get("lang", "python")
            if lang not in EXT:
                return self._send(400, {"error": "lang 必须是 python 或 cpp"})
            base = "python_代码" if lang == "python" else "cpp_代码"
            i = 1
            while os.path.exists(os.path.join(CODES_DIR, f"{base}{i}{EXT[lang]}")):
                i += 1
            name = f"{base}{i}{EXT[lang]}"
            with open(os.path.join(CODES_DIR, name), "w", encoding="utf-8") as f:
                f.write(DEFAULT_CODE[lang])
            return self._send(200, {"name": name, "lang": lang,
                                    "content": DEFAULT_CODE[lang]})
        if path == "/api/code/open":
            p = os.path.join(CODES_DIR, safe_name(body.get("name", "")))
            if not os.path.isfile(p):
                return self._send(404, {"error": "文件不存在"})
            with open(p, encoding="utf-8", errors="replace") as f:
                content = f.read()
            lang = "cpp" if p.endswith(".cpp") else "python"
            return self._send(200, {"name": os.path.basename(p), "lang": lang,
                                    "content": content})
        if path == "/api/code/save":
            name = safe_name(body.get("name", ""))
            if not name or not name.endswith(tuple(EXT.values())):
                return self._send(400, {"error": "文件名必须以 .py 或 .cpp 结尾"})
            with open(os.path.join(CODES_DIR, name), "w", encoding="utf-8") as f:
                f.write(body.get("content", ""))
            return self._send(200, {"ok": True, "name": name})
        if path == "/api/code/delete":
            p = os.path.join(CODES_DIR, safe_name(body.get("name", "")))
            if os.path.isfile(p):
                os.remove(p)
                return self._send(200, {"ok": True})
            return self._send(404, {"error": "文件不存在"})
        if path == "/api/run":
            lang = body.get("lang", "python")
            code = body.get("code", "")
            env = detect_env()
            if lang == "python":
                if not env["python"]["ok"]:
                    return self._send(200, {"ok": False, "need_setup": "python",
                                            "stderr": "未检测到 Python 环境，请先配置或下载 Python。"})
                return self._send(200, run_python(code))
            if lang == "cpp":
                if not env["cpp"]["ok"]:
                    return self._send(200, {"ok": False, "need_setup": "cpp",
                                            "stderr": "未检测到 g++ 编译器，请先配置或下载 C++ 编译器。"})
                return self._send(200, run_cpp(code))
            return self._send(400, {"error": "lang 必须是 python 或 cpp"})
        if path == "/api/ext/install":
            pkg = body.get("pkg", "")
            raw = body.get("cmd", "")
            if not pkg and not raw:
                return self._send(400, {"error": "请提供包名或 pip 命令"})
            return self._send(200, pip_install(pkg, raw))
        if path == "/api/ai/generate":
            prompt = (body.get("prompt") or "").strip()
            if not prompt:
                return self._send(400, {"error": "请输入你的需求描述"})
            return self._send(200, ai_generate(prompt, body.get("lang", "python"),
                                               body.get("model", "")))
        if path == "/api/debug/analyze":
            return self._send(200, analyze_error(body.get("error", "")))
        return self._send(404, {"error": "not found"})


def main():
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    url = f"http://127.0.0.1:{PORT}"
    print("=" * 46)
    print(f"  编程工具箱{'（开发者版）' if DEV_EDITION else ''}已启动！")
    print(f"  请在浏览器打开: {url}")
    print("  按 Ctrl+C 停止服务")
    print("=" * 46)
    try:
        webbrowser.open(url)
    except Exception:
        pass
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\n已停止。")


if __name__ == "__main__":
    main()
